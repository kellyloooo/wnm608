<?php include "parts/meta.php";?>
<footer class="footer">
        <p>@Copyright Island Soapworks All Right Reserved.</p>
    </footer>