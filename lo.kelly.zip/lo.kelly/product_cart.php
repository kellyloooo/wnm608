<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/storetheme.css">
<link rel="stylesheet" href="lib/css/styleguide.css">
 <link rel="stylesheet" href="lib/css/gridsystem.css">
    <title>Cart | Island Soapworks</title>
</head>
<body>
    <?php include "parts/navbar.php";?>

<div class="container" id="productlist">
    <div class="card soft">
        <h2>Your Cart</h2>
        <p><a href="product_checkout.php">Checkout</a></p>
    </div>
</div>


    <?php include "parts/footer.php";?>

</body>
</html>