<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css/storetheme.css">
<link rel="stylesheet" href="lib/css/styleguide.css">
 <link rel="stylesheet" href="lib/css/gridsystem.css">
    <title>About | Island Soapworks</title>
</head>
<body>
    <?php include "parts/navbar.php";?>
    <div class="hero">
        <img src="img/img_1.jpg" alt="hero">
    </div>


    <?php include "parts/footer.php";?>

</body>
</html>