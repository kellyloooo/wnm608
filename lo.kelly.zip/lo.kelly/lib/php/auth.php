<?php

function MYSQLIAuth(){
    return[
"localhost", //mysql host
"klo_wnm608", //mysql username
"klo_wnm608", //mysql user password
"klo_wnm608", //mysql database
    ];
}

function PDOAuth(){
    return[
"mysql:host=localhost;dbname=klo_wnm608", // host and database name
"klo_wnm608", //mysql username
"klo_wnm608", //mysql user password
[PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"]
    ];
}


