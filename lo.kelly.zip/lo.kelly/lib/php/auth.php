<?php

function MYSQLIAuth(){
    return[
"localhost", //mysql host
"klo_wnm608", //mysql username
"klo_wnm608", //mysql user password
"klo_wnm608", //mysql database
    ];
}

